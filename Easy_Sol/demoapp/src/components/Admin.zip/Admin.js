import React, { Component, useState } from "react";
import { Form, Button, FloatingLabel, FormControl } from "react-bootstrap";
import { App } from "../App";

function Admin() {
  let [email, setEmail] = useState(" ");
  let [password, setPassword] = useState(" ");

  async function userData(event) {
    event.preventDefault();
    const response = await fetch("http://localhost:1337/api/userdata", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        password,
      }),
    });

    const data = response.json();
    console.log(data);
  }
  return (
    <div>
      <form onSubmit={userData}>
        <input
          type="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
          }}
          placeholder="name@example.com"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
          }}
          placeholder="Password"
        />
        <input type="submit" value="submit"></input>
      </form>
    </div>
  );
}
// export default class Admin extends Component {
//   render() {
//     // eslint-disable-next-line react-hooks/rules-of-hooks

//     // eslint-disable-next-line react-hooks/rules-of-hooks

//     return (

//     );
//   }
export default Admin;
